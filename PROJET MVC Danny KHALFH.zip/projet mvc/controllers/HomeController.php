<?php
require_once 'models/SmartbikeModel.php';

class HomeController {
    public function showHomePage() {
 
        $db = new PDO('mysql:host=localhost:3306;dbname=db-dk', 'root', 'password');


        $smartbikeModel = new SmartbikeModel($db);


        $latestBike = $smartbikeModel->getLatestBike();


        include 'views/header.php';
        include 'views/home.php';
        include 'views/footer.php';
    }
}
