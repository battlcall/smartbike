<?php
require_once 'models/SmartbikeModel.php';
class ContactController {
    public function showContactForm() {

        include 'views/header.php';
        include 'views/contact.php';
        include 'views/footer.php';
    }

    public function processContactForm() {

        $db = new PDO('mysql:host=localhost:3306;dbname=db-dk', 'root', 'password');

        $smartbikeModel = new SmartbikeModel($db);

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nom = isset($_POST['nom']) ? $_POST['nom'] : '';
            $prenom = isset($_POST['prenom']) ? $_POST['prenom'] : '';
            $email = isset($_POST['email']) ? $_POST['email'] : '';
            $message = isset($_POST['message']) ? $_POST['message'] : '';

            $success = $smartbikeModel->saveContactMessage(['nom' => $nom, 'prenom' => $prenom, 'email' => $email, 'message' => $message]);

            if ($success) {

                header("Location: ?page=confirmation_contact");
                exit();
            } else {

                echo "Une erreur s'est produite lors de l'envoi du message. Veuillez réessayer.";
            }
        } else {

            header("Location: ?page=contact");
            exit();
        }
    }
}


