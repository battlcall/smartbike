<?php
require_once 'controllers/HomeController.php';
require_once 'controllers/ProduitController.php';
require_once 'controllers/OrderController.php';
require_once 'controllers/ContactController.php';

class Router {
    public function routeRequest() {
        $page = isset($_GET['page']) ? $_GET['page'] : 'accueil';

        switch ($page) {
            case 'velos':
                $controller = new ProductController();
                $controller->showAllProducts();
                break;

            case 'produit':
                $controller = new ProductController();
                $controller->showProduitDetails();
                break;

            case 'commander':
                $controller = new OrderController();
                $controller->showOrderForm();
                break;

            case 'contact':
                $controller = new ContactController();
                $controller->showContactForm();
                break;

            default:
                $controller = new HomeController();
                $controller->showHomePage();
                break;
        }
    }
    public function getPage() {
        return isset($_GET['page']) ? $_GET['page'] : 'accueil';
    }
}
?>

