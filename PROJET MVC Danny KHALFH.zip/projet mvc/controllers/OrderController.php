<?php
require_once 'models/SmartbikeModel.php';

class OrderController {
    private $smartbikeModel;
    public function showOrderForm() {
        

        $db = new PDO('mysql:host=localhost:3306;dbname=db-dk', 'root', 'password');

        $smartbikeModel = new SmartbikeModel($db);

        $bikes = $smartbikeModel->getAllBikes();

        include 'views/header.php';
        include 'views/order.php';
        include 'views/footer.php';
    }

    public function processOrder() {
        

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {

            $bikeId = isset($_POST['velo']) ? $_POST['velo'] : '';
            $nom = isset($_POST['nom']) ? $_POST['nom'] : '';
            $prenom = isset($_POST['prenom']) ? $_POST['prenom'] : '';
            $email = isset($_POST['email']) ? $_POST['email'] : '';
            $message = isset($_POST['message']) ? $_POST['message'] : '';

            $success = $this->smartbikeModel->processOrder([
                'bike_id' => $bikeId,
                'nom' => $nom,
                'prenom' => $prenom,
                'email' => $email,
                'message' => $message,
            ]);

            if ($success) {

                header("Location: ?page=confirmation_commande");
                exit();
            } else {

                echo "Une erreur s'est produite lors du traitement de la commande. Veuillez réessayer.";
            }
        } else {

            header("Location: ?page=commander");
            exit();
        }
    }
}
