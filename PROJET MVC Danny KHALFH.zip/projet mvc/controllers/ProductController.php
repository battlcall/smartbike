<?php
require_once 'models/SmartbikeModel.php';

class ProductController {
    public function showAllProducts() {

        $db = new PDO('mysql:host=localhost:3306;dbname=db-dk', 'root', 'password');


        $smartbikeModel = new SmartbikeModel($db);

        $bikes = $smartbikeModel->getAllBikes();

        include 'views/header.php';
        include 'views/products.php';
        include 'views/footer.php';
    }

    public function showProduitDetails() {

        $db = new PDO('mysql:host=localhost:3306;dbname=db-dk', 'root', 'password');


        $smartbikeModel = new SmartbikeModel($db);

        $bikeId = isset($_GET['velo']) ? $_GET['velo'] : null;

        if ($bikeId) {

            $bike = $smartbikeModel->getBikeById($bikeId);

            if ($bike) {
                include 'views/header.php';
                include 'views/produit.php';
                include 'views/footer.php';
                return;
            }
        }


        header("Location: ?page=velos");
    }
}


