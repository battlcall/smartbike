<?php

include 'header.php';
?>

<section>
    <h2>Dernier Vélo</h2>

    <?php

    $db = new PDO('mysql:host=localhost:3306;dbname=db-dk', 'root', 'password');


    $smartbikeModel = new SmartbikeModel($db);

    $latestBike = $smartbikeModel->getLatestBike();

    if ($latestBike) {
        ?>
        <div class="bike-details">
            <img src="<?php echo $latestBike['photo']; ?>" alt="Vélo <?php echo $latestBike['id']; ?>">
            <p>Description: <?php echo $latestBike['description']; ?></p>
            <p>Prix: <?php echo $latestBike['prix']; ?> €</p>
        </div>
        <?php
    } else {
        ?>
        <p>Aucun vélo disponible pour le moment.</p>
        <?php
    }
    ?>
</section>

<?php

include 'footer.php';
?>
