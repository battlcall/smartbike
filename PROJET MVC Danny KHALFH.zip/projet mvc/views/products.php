<?php

include 'header.php';
?>


<section>
    <h2>Nos Vélos</h2>
    
    <?php 

require_once 'models/SmartbikeModel.php';


$smartbikeModel = new SmartbikeModel($db);

$bikes = $smartbikeModel->getAllBikes();
    
    
    foreach ($bikes as $bike): ?>
        <div class="bike">
            <img src="<?php echo $bike['photo']; ?>" alt="Vélo <?php echo $bike['id']; ?>">
            <p>Prix: <?php echo $bike['prix']; ?> €</p>
            <a href="?page=commander&velo=<?php echo $bike['id']; ?>">Commander</a>
            <a href="?page=produit&velo=<?php echo $bike['id']; ?>">Plus d'infos</a>
        </div>
    <?php endforeach; ?>
    
</section>

<?php

include 'footer.php';
?>
