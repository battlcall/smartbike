<?php
include 'header.php';
?>

<?php


$smartbikeModel = new SmartBikeModel($db);


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'nom' => $_POST['nom'],
        'prenom' => $_POST['prenom'],
        'email' => $_POST['email'],
        'message' => $_POST['message'],
    ];

    $smartbikeModel->saveContactMessage($data);

    echo "Message envoyé avec succès!";
}


?>

<section>
    <h2>Contactez-nous</h2>


    <form action="?page=contact" method="post">
        <label for="nom">Nom:</label>
        <input type="text" name="nom" required>

        <label for="prenom">Prénom:</label>
        <input type="text" name="prenom" required>

        <label for="email">Email:</label>
        <input type="email" name="email" required>

        <label for="message">Message:</label>
        <textarea name="message" required></textarea>

        <input type="submit" value="Envoyer">
    </form>

    <div>
        <h3>SmartBike, la marque des héros</h3>
        <p>Adresse : 30-32 Av. de la République, 94800 Villejuif
            Téléphone: 01 88 28 90 00<br>
            Email: bike@smartbike.com</p>

        <iframe
            width="600"
            height="450"
            frameborder="0"
            style="border:0"
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2624.8823182243667!2d2.342119!3d48.7887737!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47e673e24e04a9c3%3A0xc55cb3e676f95321!2sEfrei!5e0!3m2!1sen!2sfr!4v1626148581034!5m2!1sen!2sfr"
            allowfullscreen=""
            loading="lazy"
        ></iframe>
    </div>
</section>

<?php

include 'footer.php';
?>

