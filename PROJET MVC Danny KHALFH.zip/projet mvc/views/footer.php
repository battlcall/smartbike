<footer>
        <p>Smartbike - Votre partenaire de confiance </p>
    </footer>
</body>
</html>
