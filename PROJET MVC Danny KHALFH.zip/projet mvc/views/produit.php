<<?php
include 'header.php';


$bikeId = isset($_GET['velo']) ? $_GET['velo'] : null;


if ($bikeId) {

    require_once 'models/SmartbikeModel.php';


    $smartbikeModel = new SmartbikeModel($db);


    $bike = $smartbikeModel->getBikeById($bikeId);

    if ($bike) {
        ?>
        <section>
            <h2>Informations sur le Vélo</h2>

            <div class="bike-details">
                <img src="<?php echo $bike['photo']; ?>" alt="Vélo <?php echo $bike['id']; ?>">
                <p>Description: <?php echo $bike['description']; ?></p>
                <p>Prix: <?php echo $bike['prix']; ?> €</p>
                <a href="?page=commander&velo=<?php echo $bike['id']; ?>">Commander</a>
            </div>
        </section>
        <?php
    } else {

        echo "Le vélo demandé n'existe pas.";
    }
} else {

    echo "L'ID du vélo n'est pas spécifié.";
}

include 'footer.php';
?>
