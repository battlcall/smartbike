<?php

include 'header.php';
?>

<section>
    <h2>Commander un Vélo</h2>

    <form action="?page=commander" method="post">
        <label for="velo">Choisir un vélo:</label>
        <select name="velo">
            <?php foreach ($bikes as $bike): ?>
                <option value="<?php echo $bike['id']; ?>"><?php echo $bike['nom']; ?></option>
            <?php endforeach; ?>
        </select>

        <label for="nom">Nom:</label>
        <input type="text" name="nom" required>

        <label for="prenom">Prénom:</label>
        <input type="text" name="prenom" required>

        <label for="email">Email:</label>
        <input type="email" name="email" required>

        <label for="message">Message:</label>
        <textarea name="message" required></textarea>

        <input type="submit" value="Envoyer">
    </form>

</section>

<?php

include 'footer.php';
?>

