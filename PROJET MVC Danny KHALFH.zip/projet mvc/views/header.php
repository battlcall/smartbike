<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smartbike</title>
    <link rel="stylesheet" type="css/style/css" href="css/style.css">


</head>
<body>
    <header>
        <img src="logo1.png" alt="Smartbike Logo">
        <nav>
            <ul>
                <li><a href="?page=accueil">Accueil</a></li>
                <li><a href="?page=velos">Vélos</a></li>
                <li><a href="?page=contact">Contact</a></li>
            </ul>
        </nav>
    </header>

