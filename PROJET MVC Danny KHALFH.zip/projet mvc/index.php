<?php
require_once 'controllers/Router.php';


$db = new PDO('mysql:host=localhost:3306;dbname=db-dk', 'root', 'password');

$smartbikeModel = new SmartbikeModel($db);

$router = new Router();
$router->routeRequest();


$latestBike = $smartbikeModel->getLatestBike();
$page = $router->getPage();


if ($router->getPage() === 'velos') {
    include 'views/products.php';
} elseif ($router->getPage() === 'produit') {
    include 'views/product.php';
} elseif ($router->getPage() === 'commander') {
    include 'views/order.php';
} elseif ($router->getPage() === 'contact') {
    include 'views/contact.php';
} else {

    include 'views/home.php';
}
?>

