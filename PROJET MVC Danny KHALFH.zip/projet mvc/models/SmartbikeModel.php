<?php

class SmartbikeModel {
    private $db;

    public function __construct(PDO $db) {
        $this->db = $db;
    }

    public function getLatestBike() {
        $query = "SELECT * FROM bikes ORDER BY id DESC LIMIT 1";
        $statement = $this->db->query($query);
        return $statement->fetch(PDO::FETCH_ASSOC);
    }

    public function getBikeById($bikeId) {
        $query = "SELECT * FROM bikes WHERE id = :id";
        $statement = $this->db->prepare($query);
        $statement->bindParam(':id', $bikeId, PDO::PARAM_INT);
        $statement->execute();
        return $statement->fetch(PDO::FETCH_ASSOC);
    }

    public function getAllBikes() {
        $query = "SELECT * FROM bikes";
        $statement = $this->db->query($query);
        return $statement->fetchAll(PDO::FETCH_ASSOC);
    }

    public function saveContactMessage($data) {
        $currentDate = date('Y-m-d H:i:s');
        
        $query = "INSERT INTO contact_messages (nom, prenom, email, message, date_envoi) VALUES (:nom, :prenom, :email, :message, :date_envoi)";
        $statement = $this->db->prepare($query);
        $statement->bindParam(':nom', $data['nom']);
        $statement->bindParam(':prenom', $data['prenom']);
        $statement->bindParam(':email', $data['email']);
        $statement->bindParam(':message', $data['message']);
        $statement->bindParam(':date_envoi', $currentDate);
        
        return $statement->execute();
    }    

    public function processOrder($data) {
        $bikeId = $data['bike_id'];
        $nom = $data['nom'];
        $prenom = $data['prenom'];
        $email = $data['email'];
        $message = $data['message'];

        try {

            $this->db->beginTransaction();
    
            $stmt = $this->db->prepare("INSERT INTO orders (bike_id, nom, prenom, email, message, date_commande) VALUES (?, ?, ?, ?, ?, NOW())");
            $stmt->execute([$bikeId, $nom, $prenom, $email, $message]);
            $this->db->commit();
    
            return true; 
        } catch (PDOException $e) {

            $this->db->rollBack();
            return false;
        }
    }
    

}

